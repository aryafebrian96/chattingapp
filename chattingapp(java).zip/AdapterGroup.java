package com.example.arya.apppertama;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by ARYA on 12/30/2016.
 */

public class AdapterGroup extends ArrayAdapter<String> {

    private Context context;
    private List<ModelGroup> modelGroups;

    public AdapterGroup(Context context, int resource, List<ModelGroup> modelGroups) {
        super(context, resource);
        this.context = context;
        this.modelGroups = modelGroups;
    }

    @Override
    public int getCount() {
        return modelGroups.size();
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.item_group , parent, false);

        ((TextView) convertView.findViewById(R.id.groupName)).setText(modelGroups.get(position).getName());

        return convertView;
    }
}
