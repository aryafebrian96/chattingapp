package com.example.arya.apppertama;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class BerandaChatt extends AppCompatActivity {

    private ListView listGroup;
    private EditText etGroup;
    private Button bGroup;
//    private List<ModelGroup> modelGroups = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda_chatt);

//        ModelChatting chattng1 = new ModelChatting("", "1", "1", "Arya", "test");
//        ModelChatting chattng2 = new ModelChatting("", "2", "1", "Bayu", "Apa");
//        ModelChatting chattng3 = new ModelChatting("", "1", "1", "Arya", "test lagi");
//        ModelChatting chattng4 = new ModelChatting("", "3", "2", "Peter", "Hallo");
//        ModelChatting chattng5 = new ModelChatting("", "1", "2", "Arya", "Hay");
//
//        List<ModelChatting> list1 = new ArrayList<>();
//        list1.add(chattng1);
//        list1.add(chattng2);
//        list1.add(chattng3);
//        ModelGroup group1 = new ModelGroup("1", "Kursus", list1);
//
//        List<ModelChatting> list2 = new ArrayList<>();
//        list2.add(chattng4);
//        list2.add(chattng5);
//        ModelGroup group2 = new ModelGroup("2", "Administrasi", list2);
//
//        modelGroups.add(group1);
//        modelGroups.add(group2);

        listGroup = ((ListView) findViewById(R.id.listGroup));
        listGroup.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Globals.chatsGlobal = Globals.groupGlobal.get(i).getChattings();
                startActivity(new Intent(BerandaChatt.this, GroupChatt.class));
            }
        });
        listGroup.setAdapter(new AdapterGroup(this, R.layout.item_group, Globals.groupGlobal));

        bGroup = (Button) findViewById(R.id.addGroup);
        etGroup = (EditText) findViewById(R.id.editTextGroup);
        bGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!etGroup.equals("")){
                    addToFirebase();
                }
            }
        });

        grabFromFirebase();
    }

    void addToFirebase() {
        ModelGroup group = new ModelGroup("", etGroup.getText().toString(), new ArrayList<ModelChatting>());
        Globals.groupGlobal.add(group);

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Group");
        databaseReference.setValue(Globals.groupGlobal);

    }

    void grabFromFirebase() {


        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Group");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<ModelGroup> modelGroups = new ArrayList<ModelGroup>();
                for ( DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    ModelGroup group = snapshot.getValue(ModelGroup.class);
                    modelGroups.add(group);
                }
                Globals.groupGlobal = modelGroups;
                listGroup.setAdapter(new AdapterGroup(BerandaChatt.this, R.layout.item_group, Globals.groupGlobal));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
