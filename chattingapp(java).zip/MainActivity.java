package com.example.arya.apppertama;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Barang barang1 = new Barang("Gula", new Date(), 250000);
        Barang barang2 = new Barang("Sembako", new Date(), 350000);
        Barang barang3 = new Barang("Laptop", new Date(), 550000);
        Barang barang4 = new Barang("Kabel", new Date(), 600000);
        Barang barang5 = new Barang("Charger", new Date(), 750000);

        List<Barang> barangs1 = new ArrayList<>();
        barangs1.add(barang1);
        barangs1.add(barang3);
        barangs1.add(barang5);
        List<Barang> barangs2 = new ArrayList<>();
        barangs2.add(barang2);
        barangs2.add(barang4);

        Pembelian pembelian1 = new Pembelian("Agus");
        pembelian1.setCustomer("STIKOM");
        pembelian1.setHarga(5000000);
        pembelian1.setTanggalpembelian(new Date());
        Pembelian pembelian2 = new Pembelian(1250000);
        pembelian2.setCustomer("ITS");
        pembelian2.setHarga(750000);

        pembelian1.setBarang(barangs1);
        pembelian2.setBarang(barangs2);

        Log.i("BARANG PERTAMA",pembelian1.toString());
        Log.i("BARANG KEDUA", pembelian2.toString());
    }
}
