package com.example.arya.apppertama;

/**
 * Created by ARYA on 12/30/2016.
 */

public class ModelChatting {

    private String tgl;
    private String idUser;
    private String idGroup;
    private String nameUser;
    private String isi;

    public ModelChatting(String tgl, String idUser, String idGroup, String nameUser, String isi) {
        this.tgl = tgl;
        this.idUser = idUser;
        this.idGroup = idGroup;
        this.nameUser = nameUser;
        this.isi = isi;
    }

    public String getTgl() {
        return tgl;
    }

    public void setTgl(String tgl) {
        this.tgl = tgl;
    }

    public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public String getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(String idGroup) {
        this.idGroup = idGroup;
    }

    public String getIsi() {
        return isi;
    }

    public void setIsi(String isi) {
        this.isi = isi;
    }

    public String getNameUser() {
        return nameUser;
    }

    public void setNameUser(String nameUser) {
        this.nameUser = nameUser;
    }
}
