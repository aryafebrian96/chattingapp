package com.example.arya.apppertama;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ARYA on 12/30/2016.
 */

public class ModelUser {

    private String id;
    private String nama;
    private List<ModelGroup> groups = new ArrayList<>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public List<ModelGroup> getGroups() {
        return groups;
    }

    public void setGroups(List<ModelGroup> groups) {
        this.groups = groups;
    }
}
