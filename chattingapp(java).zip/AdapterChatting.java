package com.example.arya.apppertama;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ARYA on 12/30/2016.
 */

public class AdapterChatting extends ArrayAdapter<String> {

    private Context context;
    private List<ModelChatting> modelChattings = new ArrayList<>();

    public AdapterChatting(Context context, int resource, List<ModelChatting> modelChattings) {
        super(context, resource);
        this.context = context;
        this.modelChattings = modelChattings;
    }

    @Override
    public int getCount() {
        return modelChattings.size();
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.item_chat, parent, false);

        ((TextView) convertView.findViewById(R.id.userName)).setText(modelChattings.get(position).getNameUser());
        ((TextView) convertView.findViewById(R.id.chat)).setText(modelChattings.get(position).getIsi());

        return convertView;
    }
}
