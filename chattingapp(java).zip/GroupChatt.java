package com.example.arya.apppertama;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class GroupChatt extends AppCompatActivity {

    private ListView listChat;
    private ListView listGroup;
    private EditText etGroup;
    private Button bGroup;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chatt);

        listChat = ((ListView) findViewById(R.id.listChat));
        listChat.setAdapter(new AdapterChatting(this, R.layout.item_chat, Globals.chatsGlobal));


        bGroup = (Button) findViewById(R.id.addGroup);
        etGroup = (EditText) findViewById(R.id.editTextGroup);
        bGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!etGroup.equals("")){
                    addToFirebase();
                }
            }
        });

        grabFromFirebase();

    }

    void addToFirebase() {
        ModelGroup group = new ModelGroup("", etGroup.getText().toString(), new ArrayList<ModelGroup>());
        Globals.groupGlobal.add(group);

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Group");
        databaseReference.setValue(Globals.groupGlobal);

    }

    void grabFromFirebase() {


        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Group");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<ModelGroup> modelGroups2 = new ArrayList<ModelGroup>();
                for ( DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    ModelGroup group = snapshot.getValue(ModelGroup.class);
                    modelGroups2.add(group);
                }
                Globals.groupGlobal = modelGroups2;
                listGroup.setAdapter(new AdapterGroup(GroupChatt.this, R.layout.item_group, Globals.groupGlobal));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
