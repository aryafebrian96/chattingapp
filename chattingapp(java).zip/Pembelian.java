package com.example.arya.apppertama;

import java.util.Date;
import java.util.List;

/**
 * Created by ARYA on 12/20/2016.
 */

public class Pembelian {

    private String nama;
    private String customer;
    private int harga;
    private double totalharga;
    private Date tanggalpembelian;
    private List<Barang> barang;

    public Pembelian() {
    }

    public Pembelian(String nama) {
        this.nama = nama;
    }


    public Pembelian(int harga) {
        this.harga = harga;
    }



    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public double getTotalharga() {
        return totalharga;
    }

    public void setTotalharga(double totalharga) {
        this.totalharga = totalharga;
    }

    public Date getTanggalpembelian() {
        return tanggalpembelian;
    }

    public void setTanggalpembelian(Date tanggalpembelian) {
        this.tanggalpembelian = tanggalpembelian;
    }

    public List<Barang> getBarang() {
        return barang;
    }

    public void setBarang(List<Barang> barang) {
        this.barang = barang;
    }

    @Override
    public String toString() {
        return "Pembelian{" +
                "nama='" + nama + '\'' +
                ", customer='" + customer + '\'' +
                ", harga=" + harga +
                ", totalharga=" + totalharga +
                ", tanggalpembelian=" + tanggalpembelian +
                ", barang=" + barang +
                '}';
    }
}
