package com.example.arya.apppertama;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ARYA on 12/30/2016.
 */

public class ModelGroup {

    private String id;
    private String name;
    private List<ModelChatting> chattings = new ArrayList<>();


    public ModelGroup() {
    }

    public ModelGroup(String id, String name, List<ModelChatting> chattings) {
        this.id = id;
        this.name = name;
        this.chattings = chattings;
    }

    public ModelGroup(String id, String name, ArrayList<ModelGroup> modelGroups) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ModelChatting> getChattings() {
        return chattings;
    }

    public void setChattings(List<ModelChatting> chattings) {
        this.chattings = chattings;
    }
}
