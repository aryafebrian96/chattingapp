package com.example.arya.apppertama;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ARYA on 12/30/2016.
 */

public class Globals {

    public static List<ModelGroup> groupGlobal = new ArrayList<>();
    public static List<ModelChatting> chatsGlobal = new ArrayList<>();
}
