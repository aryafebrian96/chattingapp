package com.example.arya.apppertama;

import java.util.Date;

/**
 * Created by ARYA on 12/20/2016.
 */

public class Barang {

    private String namabarang;
    private Date barangdatang;
    private int hargabarang;

    public Barang(String namabarang, Date barangdatang, int hargabarang) {
        this.namabarang = namabarang;
        this.barangdatang = barangdatang;
        this.hargabarang = hargabarang;
    }

    public String getNamabarang() {
        return namabarang;
    }

    public void setNamabarang(String namabarang) {
        this.namabarang = namabarang;
    }

    public Date getBarangdatang() {
        return barangdatang;
    }

    public void setBarangdatang(Date barangdatang) {
        this.barangdatang = barangdatang;
    }

    public int getHargabarang() {
        return hargabarang;
    }

    public void setHargabarang(int hargabarang) {
        this.hargabarang = hargabarang;
    }

    @Override
    public String toString() {
        return "Barang{" +
                "namabarang='" + namabarang + '\'' +
                ", barangdatang=" + barangdatang +
                ", hargabarang=" + hargabarang +
                '}';
    }
}
